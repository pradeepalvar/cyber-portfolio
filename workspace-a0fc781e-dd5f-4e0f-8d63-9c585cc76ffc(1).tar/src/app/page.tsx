'use client'

import { useEffect } from 'react'

export default function Home() {
  useEffect(() => {
    window.location.replace('/index.html')
  }, [])
  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <div className="text-green-500 animate-pulse">Loading portfolio...</div>
    </div>
  )
}
